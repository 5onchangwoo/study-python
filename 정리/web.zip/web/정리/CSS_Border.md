# Border
border는 박스의 경계면에 대한 설정을 담당한다.
## Border의 기본 속성
속성에는 top, bottom, left, right등 각 위치의 경계선을 설정할 수 있다. 
### border-width
### border-style
경계선 모양 설정
- none
- hidden
- dotted
- dashed
- solid
- double
- groove
- ridge
- inset
- outset
### border-color
### border-radius
테두리를 원형처리하는 속성
1. 값 1개 
- 4개의 모서리 동시 적용
2. 값 2개 
- 2개씩 적용(top-left and bottom-right | top-right and bottom-left)
3. 값 3개
- 1개, 2개, 1개순으로 따로 적용(top-left | top-right and bottom-left | bottom-right)
4. 값 4개
- 4개의 모서리  따로 적용(top-left, top-right, bottom-right, bottom-left)

