# Multi-column layout
https://developer.mozilla.org/ko/docs/Web/CSS/CSS_Columns


## 박스없이 콘텐츠를 여러 컬럼으로 나누기
### `column-count: <value>;`
콘텐츠 레이아웃.
- 추가 속성
  - `column-gap: <value>;`
    - 각 컬럼 사이 여백 크기조절
  - `column-rule:< width style color >;`
    - 여백에 선 너비, 스타일, 색상 추가.
    - `color-rule-color`
    - `color-rule-style`
    - `color-rule-width`